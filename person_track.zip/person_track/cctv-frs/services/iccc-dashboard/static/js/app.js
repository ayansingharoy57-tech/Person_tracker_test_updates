document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const uploadZone = document.getElementById('uploadZone');
    const fileInput = document.getElementById('fileInput');
    const targetName = document.getElementById('targetName');
    const enrollBtn = document.getElementById('enrollBtn');
    const targetsList = document.getElementById('targetsList');
    const targetCount = document.getElementById('targetCount');

    const startBtn = document.getElementById('startBtn');
    const stopBtn = document.getElementById('stopBtn');
    const feedPlaceholder = document.getElementById('feedPlaceholder');
    const feedImage = document.getElementById('feedImage');
    const thresholdSlider = document.getElementById('thresholdSlider');
    const thresholdValue = document.getElementById('thresholdValue');

    const systemStatus = document.getElementById('systemStatus');
    const statusText = document.getElementById('statusText');
    const fpsCounter = document.getElementById('fpsCounter');

    const noMatchState = document.getElementById('noMatchState');
    const matchCard = document.getElementById('matchCard');
    const matchTargetImg = document.getElementById('matchTargetImg');
    const matchDetectedImg = document.getElementById('matchDetectedImg');
    const matchName = document.getElementById('matchName');
    const matchConfidence = document.getElementById('matchConfidence');
    const matchTargetId = document.getElementById('matchTargetId');
    const matchCamera = document.getElementById('matchCamera');
    const matchTimestamp = document.getElementById('matchTimestamp');
    const matchBadge = document.getElementById('matchBadge');
    const historyList = document.getElementById('historyList');

    const toastContainer = document.getElementById('toastContainer');

    // Global variables
    let selectedFile = null;
    let ws = null;
    let statsInterval = null;

    // Toast utility
    function showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <span>${type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️'}</span>
            <span>${message}</span>
        `;
        toastContainer.appendChild(toast);
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    // Load watchlist on page load
    async function loadWatchlist() {
        try {
            const response = await fetch('/api/v1/watchlist/targets');
            const data = await response.json();
            targetCount.textContent = `${data.count} targets`;
            targetsList.innerHTML = '';

            data.targets.forEach(t => {
                const item = document.createElement('div');
                item.className = 'target-item';
                item.innerHTML = `
                    <img src="data:image/jpeg;base64,${t.face_crop_b64}" class="target-img" alt="Target crop">
                    <div class="target-details">
                        <div class="target-name">${t.target_name}</div>
                        <div class="target-time">${new Date(t.enrolled_at).toLocaleTimeString()}</div>
                    </div>
                    <button class="target-remove" data-id="${t.target_id}">✕</button>
                `;
                targetsList.appendChild(item);
            });
        } catch (e) {
            console.error('Error loading watchlist', e);
        }
    }

    // Target remove handler
    targetsList.addEventListener('click', async (e) => {
        if (e.target.classList.contains('target-remove')) {
            const targetId = e.target.getAttribute('data-id');
            try {
                const response = await fetch(`/api/v1/watchlist/targets/${targetId}`, {
                    method: 'DELETE'
                });
                if (response.ok) {
                    showToast('Target removed successfully', 'success');
                    loadWatchlist();
                } else {
                    const err = await response.json();
                    showToast(err.detail, 'error');
                }
            } catch (err) {
                showToast('Network error during removal', 'error');
            }
        }
    });

    // File Upload Handling
    uploadZone.addEventListener('click', () => fileInput.click());

    uploadZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadZone.style.borderColor = 'var(--primary-color)';
    });

    uploadZone.addEventListener('dragleave', () => {
        uploadZone.style.borderColor = 'rgba(255, 255, 255, 0.15)';
    });

    uploadZone.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadZone.style.borderColor = 'rgba(255, 255, 255, 0.15)';
        if (e.dataTransfer.files.length > 0) {
            handleFileSelect(e.dataTransfer.files[0]);
        }
    });

    fileInput.addEventListener('change', () => {
        if (fileInput.files.length > 0) {
            handleFileSelect(fileInput.files[0]);
        }
    });

    function handleFileSelect(file) {
        selectedFile = file;
        uploadZone.querySelector('p').textContent = `Selected: ${file.name}`;
        enrollBtn.disabled = false;
    }

    enrollBtn.addEventListener('click', async () => {
        if (!selectedFile) return;

        const formData = new FormData();
        formData.append('file', selectedFile);
        formData.append('target_name', targetName.value.trim() || 'Unknown Target');

        enrollBtn.disabled = true;
        enrollBtn.textContent = 'Enrolling...';

        try {
            const response = await fetch('/api/v1/watchlist/enroll', {
                method: 'POST',
                body: formData
            });

            if (response.ok) {
                showToast('Target enrolled successfully', 'success');
                selectedFile = null;
                targetName.value = '';
                fileInput.value = '';
                uploadZone.querySelector('p').innerHTML = 'Drop target image here or click to upload';
                await loadWatchlist();
                
                // Auto-start pipeline if not running
                try {
                    const statusResponse = await fetch('/api/v1/feed/status');
                    const statusData = await statusResponse.json();
                    if (!statusData.running) {
                        startBtn.click();
                    }
                } catch (statusErr) {
                    console.error('Failed to auto-check feed status', statusErr);
                }
            } else {
                const err = await response.json();
                showToast(err.detail || 'Enrollment failed', 'error');
            }
        } catch (e) {
            showToast('Network error during enrollment', 'error');
        } finally {
            enrollBtn.disabled = false;
            enrollBtn.textContent = 'Enroll';
        }
    });

    // Feed Controls
    startBtn.addEventListener('click', async () => {
        try {
            const camSource = encodeURIComponent(document.getElementById('cameraSource').value.trim() || '0');
            const response = await fetch(`/api/v1/feed/start?source=${camSource}`, { method: 'POST' });
            if (response.ok) {
                showToast('Camera feed started', 'success');
                startBtn.disabled = true;
                stopBtn.disabled = false;
                feedPlaceholder.style.display = 'none';
                feedImage.style.display = 'block';
                feedImage.src = '/api/v1/feed/stream';
                connectWebSocket();
            } else {
                const err = await response.json();
                showToast(err.detail || 'Failed to start feed', 'error');
            }
        } catch (e) {
            showToast('Network error starting feed', 'error');
        }
    });

    stopBtn.addEventListener('click', async () => {
        try {
            const response = await fetch('/api/v1/feed/stop', { method: 'POST' });
            if (response.ok) {
                showToast('Camera feed stopped', 'info');
                startBtn.disabled = false;
                stopBtn.disabled = true;
                feedPlaceholder.style.display = 'flex';
                feedImage.style.display = 'none';
                feedImage.removeAttribute('src');
                disconnectWebSocket();
                noMatchState.style.display = 'flex';
                matchCard.style.display = 'none';
                matchBadge.style.display = 'none';
                fpsCounter.textContent = '0 FPS';
            }
        } catch (e) {
            showToast('Network error stopping feed', 'error');
        }
    });

    // Threshold control
    thresholdSlider.addEventListener('input', () => {
        thresholdValue.textContent = parseFloat(thresholdSlider.value).toFixed(2);
    });

    thresholdSlider.addEventListener('change', async () => {
        const val = parseFloat(thresholdSlider.value);
        try {
            await fetch(`/api/v1/feed/threshold?value=${val}`, { method: 'POST' });
            showToast(`Threshold updated to ${val.toFixed(2)}`, 'info');
        } catch (e) {
            console.error('Failed to update threshold', e);
        }
    });

    // WebSocket matching notifications
    function connectWebSocket() {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        ws = new WebSocket(`${protocol}//${window.location.host}/ws/events`);

        ws.onopen = () => {
            systemStatus.querySelector('.status-dot').className = 'status-dot online';
            statusText.textContent = 'Operational';
        };

        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            if (data.type === 'match') {
                const match = data.payload;
                displayMatch(match);
            }
        };

        ws.onclose = () => {
            systemStatus.querySelector('.status-dot').className = 'status-dot offline';
            statusText.textContent = 'Offline';
        };
    }

    function disconnectWebSocket() {
        if (ws) {
            ws.close();
            ws = null;
        }
    }

    function displayMatch(match) {
        noMatchState.style.display = 'none';
        matchCard.style.display = 'block';
        matchBadge.style.display = 'block';

        // Update card details
        matchName.textContent = match.target_name;
        matchConfidence.textContent = `${(match.confidence * 100).toFixed(1)}%`;
        matchTargetId.textContent = match.target_id;
        matchCamera.textContent = match.camera_id;
        matchTimestamp.textContent = new Date(match.timestamp).toLocaleTimeString();

        // Update images
        matchDetectedImg.src = `data:image/jpeg;base64,${match.face_crop_b64}`;
        matchTargetImg.src = `data:image/jpeg;base64,${match.target_image_b64}`;

        // Add to history
        const histItem = document.createElement('div');
        histItem.className = 'history-item';
        histItem.innerHTML = `
            <img src="data:image/jpeg;base64,${match.face_crop_b64}" class="history-img" alt="Match thumbnail">
            <div class="history-info">
                <div class="history-name">${match.target_name}</div>
                <div class="history-score">${(match.confidence * 100).toFixed(0)}% Match</div>
            </div>
            <div class="history-time">${new Date(match.timestamp).toLocaleTimeString()}</div>
        `;
        historyList.insertBefore(histItem, historyList.firstChild);

        // Keep history list bounded to top 5
        if (historyList.children.length > 5) {
            historyList.lastChild.remove();
        }
    }

    // Poll status periodically (FPS, model loaded status)
    function startStatsPolling() {
        statsInterval = setInterval(async () => {
            try {
                const response = await fetch('/api/v1/feed/status');
                const data = await response.json();
                if (data.running) {
                    fpsCounter.textContent = `${data.fps} FPS`;
                    startBtn.disabled = true;
                    stopBtn.disabled = false;
                    if (!ws) connectWebSocket();
                    // Sync active state UI
                    if (feedImage.style.display !== 'block') {
                        feedPlaceholder.style.display = 'none';
                        feedImage.style.display = 'block';
                        feedImage.src = '/api/v1/feed/stream';
                    }
                } else {
                    fpsCounter.textContent = '0 FPS';
                    startBtn.disabled = false;
                    stopBtn.disabled = true;
                    // Sync inactive state UI
                    if (feedImage.style.display !== 'none') {
                        feedPlaceholder.style.display = 'flex';
                        feedImage.style.display = 'none';
                        feedImage.removeAttribute('src');
                        disconnectWebSocket();
                    }
                }
            } catch (e) {
                console.error('Stats polling failed', e);
            }
        }, 1000);
    }

    // Init
    loadWatchlist();
    startStatsPolling();
});
