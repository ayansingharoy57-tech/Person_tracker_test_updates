# CCTV FRS — Model Registry

This directory contains model registry references and versioned configuration files.

**No model weights are stored in this repository.**

Model artifacts (weights, configs, benchmark reports) are stored in object storage under:
```
model-artifacts/{model_name}/{version}/
```

## Current Models

| Model | Purpose | Dimensions | Provider |
|---|---|---|---|
| `buffalo_l` | Face detection + ArcFace embedding | 512-d | InsightFace |

## Notes
- InsightFace models are auto-downloaded on first run via `onnxruntime`.
- Model version pinning is managed via `config/` on edge nodes.
