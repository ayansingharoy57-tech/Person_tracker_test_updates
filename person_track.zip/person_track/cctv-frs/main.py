"""
CCTV FRS — ASGI Entry Point.

Combines all service routers (watchlist-service, edge-inference,
recognition-service, iccc-dashboard) and initializes the shared
InsightFace ArcFace detection models on startup.
"""

import logging
import asyncio
import importlib
from fastapi import FastAPI
from contextlib import asynccontextmanager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("cctv-frs.main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifecycle manager for model loading and pipeline cleanup."""
    # 1. Initialize InsightFace model
    edge_init = importlib.import_module("services.edge-inference")
    
    # Load model in a separate thread so it doesn't block the ASGI server startup
    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(None, edge_init.init_face_app)
    except Exception as e:
        logger.error(f"Failed to load detection model during startup: {e}")

    # 2. Start WebSocket broadcast loop
    dashboard_router_mod = importlib.import_module("services.iccc-dashboard.router")
    broadcast_task = asyncio.create_task(dashboard_router_mod.broadcast_loop())

    yield

    # Cleanup
    logger.info("Shutting down CCTV FRS. Cleaning up pipelines...")
    broadcast_task.cancel()
    
    pipeline_mod = importlib.import_module("services.edge-inference.pipeline")
    await pipeline_mod.pipeline.stop()


# Initialize FastAPI APP
app = FastAPI(
    title="CCTV FRS",
    description="City-Scale CCTV Face Recognition & Tracking Pipeline (Target Detection & Verification)",
    version="1.0.0",
    lifespan=lifespan
)

# Load routers dynamically using importlib to bypass Python import syntax limits on hyphenated folders
watchlist_router = importlib.import_module("services.watchlist-service.router").router
edge_router = importlib.import_module("services.edge-inference.router").router
recognition_router = importlib.import_module("services.recognition-service.router").router
dashboard_router_mod = importlib.import_module("services.iccc-dashboard.router")

# Mount Static Files first
dashboard_router_mod.mount_static_files(app)

# Include Routers
app.include_router(watchlist_router)
app.include_router(edge_router)
app.include_router(recognition_router)
app.include_router(dashboard_router_mod.router)

logger.info("FastAPI Application initialized successfully with all dynamic routers.")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
