"""
ICCC Dashboard — Operator web app, GIS map, video wall.

For this detection-only phase, provides:
- Target image upload form
- Live camera feed display (MJPEG)
- Match result display with verification confirmation
- Camera control (start/stop)
"""
