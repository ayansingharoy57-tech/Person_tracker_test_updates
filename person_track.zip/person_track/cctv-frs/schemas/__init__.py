"""
Schemas package — Versioned message contracts for inter-service communication.

Provides Pydantic models for:
- FaceEvent: Edge → Bus → Recognition Service
- MatchResult: Recognition Service → Dashboard
"""

from .face_event import FaceEvent
from .match_result import MatchResult

__all__ = ["FaceEvent", "MatchResult"]
