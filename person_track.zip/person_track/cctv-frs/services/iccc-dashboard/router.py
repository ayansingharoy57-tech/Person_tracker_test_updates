"""
ICCC Dashboard — API / Frontend Router.

Endpoints:
  GET /              — Render dashboard index page
  WS  /ws/events     — WebSockets for live match alerts from the pipeline event queue
"""

import logging
import asyncio
import importlib
from fastapi import APIRouter, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import os

logger = logging.getLogger(__name__)

# Dynamic path resolution to find templates and static directories
current_dir = os.path.dirname(os.path.abspath(__file__))
templates_dir = os.path.join(current_dir, "templates")
static_dir = os.path.join(current_dir, "static")

templates = Jinja2Templates(directory=templates_dir)

router = APIRouter(tags=["dashboard"])

# List to track active WebSocket connections
_active_connections = []


def _get_pipeline():
    """Lazy import of edge pipeline to avoid circular dependency."""
    mod = importlib.import_module("services.edge-inference.pipeline")
    return mod.pipeline


@router.get("/", response_class=HTMLResponse)
async def dashboard_index(request: Request):
    """Render the dashboard main page."""
    return templates.TemplateResponse(request, "index.html")


@router.websocket("/ws/events")
async def websocket_events(websocket: WebSocket):
    """
    WebSocket endpoint for real-time match events.

    Listens to the edge-inference event queue and broadcasts
    target matches to the connected dashboard clients.
    """
    await websocket.accept()
    _active_connections.append(websocket)
    logger.info(f"WebSocket client connected. Active: {len(_active_connections)}")

    try:
        # Keep connection open and check for events
        while True:
            # We just need to keep the socket alive. The background broadcaster (broadcast_loop)
            # handles sending data from the pipeline queue.
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        if websocket in _active_connections:
            _active_connections.remove(websocket)
        logger.info(f"WebSocket client disconnected. Active: {len(_active_connections)}")


async def broadcast_loop():
    """
    Background loop that polls events from the pipeline event_queue
    and broadcasts matches to all active WebSocket clients.
    """
    logger.info("Starting dashboard WebSocket broadcast loop...")
    pipeline = _get_pipeline()

    while True:
        try:
            # Wait for a match event from the pipeline
            match_event = await pipeline.event_queue.get()

            # Broadcast to all active clients
            if _active_connections:
                payload = {
                    "type": "match",
                    "payload": {
                        "target_id": match_event["target_id"],
                        "target_name": match_event["target_name"],
                        "confidence": match_event["confidence"],
                        "threshold": match_event["threshold"],
                        "camera_id": match_event["camera_id"],
                        "timestamp": datetime_to_iso(match_event.get("timestamp")),
                        "face_crop_b64": match_event["face_crop_b64"],
                        "target_image_b64": match_event["target_image_b64"],
                    }
                }
                for conn in list(_active_connections):
                    try:
                        await conn.send_json(payload)
                    except Exception as e:
                        logger.warning(f"Failed to send websocket message, removing client: {e}")
                        if conn in _active_connections:
                            _active_connections.remove(conn)

            pipeline.event_queue.task_done()
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.error(f"Error in WebSocket broadcast loop: {e}")
            await asyncio.sleep(1)


def datetime_to_iso(dt):
    """Format datetime helper."""
    from datetime import datetime
    if not dt:
        return datetime.utcnow().isoformat() + "Z"
    if isinstance(dt, datetime):
        return dt.isoformat() + "Z"
    return str(dt)


def mount_static_files(app):
    """Mount the static directory into the main FastAPI application."""
    if os.path.exists(static_dir):
        app.mount("/static", StaticFiles(directory=static_dir), name="static")
        logger.info(f"Mounted static files from: {static_dir}")
    else:
        logger.warning(f"Static directory not found at: {static_dir}")
